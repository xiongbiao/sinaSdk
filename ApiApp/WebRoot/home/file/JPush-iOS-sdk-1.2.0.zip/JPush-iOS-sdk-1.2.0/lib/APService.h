//
//  APService.h
//  APService
//
//  Created by LiDong on 12-8-13.
//  Copyright (c) 2012年 HXHG. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString * const kAPNetworkDidSetupNotification;
extern NSString * const kAPNetworkDidCloseNotification;
extern NSString * const kAPNetworkDidRegisterNotification;
extern NSString * const kAPNetworkDidLoginNotification;
extern NSString * const kAPNetworkDidLogoutNotification;
extern NSString * const kAPNetworkDidReceiveMessageNotification;

@interface APService : NSObject

// 初始化Push
+ (void)setupWithOption:(NSDictionary *)launchingOption;
// 注册远程通知类型
+ (void)registerForRemoteNotificationTypes:(int)types;
// 注册上报Device Token
+ (void)registerDeviceToken:(NSData *)deviceToken;
// 处理收到的Push消息
+ (void)handleRemoteNotification:(NSDictionary *)remoteInfo;
// 设置标签和别名
+ (void)setTags:(NSSet *)tags alias:(NSString * const )alias;
// UDID
+ (NSString *)openUDID;

@end
