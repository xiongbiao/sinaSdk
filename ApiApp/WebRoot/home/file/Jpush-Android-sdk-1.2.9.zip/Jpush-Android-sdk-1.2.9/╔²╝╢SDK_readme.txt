替换项目里的的  libs/jpush-sdk-release.jar 与 libs/armeabi/libpushprotocol.so
删除 cn.jpush.android.service.PushReceiver 的 Intent <action android:name="android.intent.action.BOOT_COMPLETED" />