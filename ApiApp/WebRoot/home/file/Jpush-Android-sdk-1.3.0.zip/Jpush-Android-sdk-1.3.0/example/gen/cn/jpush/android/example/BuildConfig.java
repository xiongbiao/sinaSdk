/** Automatically generated file. DO NOT MODIFY */
package cn.jpush.android.example;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}