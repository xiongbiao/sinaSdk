package cn.jpush.android.example;

import java.util.HashSet;
import java.util.Set;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import cn.jpush.android.api.InstrumentedActivity;
import cn.jpush.android.api.JPushInterface;

public class MainActivity extends InstrumentedActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        ((Button) findViewById(R.id.register)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                JPushInterface.init(getApplicationContext());
                JPushInterface.reportError(getApplicationContext(), "exception");
                JPushInterface.reportEvent(getApplicationContext(), "load app");
                JPushInterface.reportEvent(getApplicationContext(), "load app", "TAG");
                JPushInterface.reportEventDuration(getApplicationContext(), "load app", 12344);
            }
        });
        
        ((Button) findViewById(R.id.setTagsAndAlias)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            	  Set<String> s = new HashSet<String>();
                  s.add("tag");
                  s.add("fruit");
                  JPushInterface.setAliasAndTags(getApplicationContext(), "alais1", s);
            }
        });
        

        ((Button) findViewById(R.id.setPushTime)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                  JPushInterface.enableNotification(getApplicationContext(), true, "1357_3^10-12^20");
            }
        });

    }
}
